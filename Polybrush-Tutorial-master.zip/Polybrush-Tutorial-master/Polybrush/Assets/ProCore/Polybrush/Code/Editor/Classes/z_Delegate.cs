namespace Polybrush
{
	public delegate void Delegate<T>(T value);
}
