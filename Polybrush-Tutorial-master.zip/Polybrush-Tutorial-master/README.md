# Polybrush
Project files for my tutorial on using Polybrush in Unity to easily sculpt, paint, detail and texture your levels.

Check out my [YouTube Channel](http://youtube.com/brackeys) for more tutorials.

Everything is free to use, also commercially (public domain).